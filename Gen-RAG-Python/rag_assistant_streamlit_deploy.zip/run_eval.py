"""
Match the sample_document.txt against eval_qa.json to sanity-check retrieval +
answer quality. Run this after generating the sample doc, or any time you change
chunking/retrieval settings in app.py.

Usage:
    python run_eval.py

Note: you'll see repeated "missing ScriptRunContext" / "Session state does not
function..." warnings when this runs. That's expected and harmless — this script
imports app.py's plain Python functions directly without going through
`streamlit run`, so Streamlit is just telling you its UI machinery isn't active.
The actual chunking/retrieval/answer logic below doesn't touch any of that.
"""

import json
import logging
import sys

logging.getLogger("streamlit").setLevel(logging.ERROR)  # silence bare-mode warnings

sys.path.insert(0, ".")
from app import chunk_text, build_index, retrieve, generate_answer  # noqa: E402

with open("sample_document.txt") as f:
    text = f.read()

with open("eval_qa.json") as f:
    eval_qa = json.load(f)

chunks = chunk_text(text)
vectorizer, matrix = build_index(chunks)

print(f"Document chunked into {len(chunks)} chunks.\n")

correct = 0
for item in eval_qa:
    q = item["question"]
    results = retrieve(q, vectorizer, matrix, chunks, k=3)
    context_chunks = [c for c, _ in results]
    answer = generate_answer(q, context_chunks, api_key=None)  # template fallback, no API key needed

    hit = any(kw.lower() in answer.lower() for kw in item["expected_answer_contains"])
    correct += hit
    status = "MATCH" if hit else "MISS"
    print(f"[{status}] Q: {q}")
    if not hit:
        print(f"         expected one of: {item['expected_answer_contains']}")
        print(f"         top chunk retrieved: {context_chunks[0][:100]}...")
    print()

print(f"Matched {correct}/{len(eval_qa)} ({100*correct/len(eval_qa):.0f}%)")
