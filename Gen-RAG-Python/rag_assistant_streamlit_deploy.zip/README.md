# RAG Assistant — Streamlit Deployment Package

A document-upload RAG assistant, packaged for [Streamlit Community Cloud](https://streamlit.io/cloud)
deployment (or running locally). Same pipeline and sample data as the Gradio
package, so you can compare both side by side.

**Files in this package:**
- `app.py` — the Streamlit app
- `requirements.txt` — dependencies, installed automatically by Streamlit Cloud
- `sample_document.txt` — 100-line test document (fictional SaaS company knowledge base)
- `eval_qa.json` — 10 question/answer pairs matched to facts in `sample_document.txt`
- `run_eval.py` — scores the app's retrieval + answers against `eval_qa.json`

---

## 1. Run it locally first (Anaconda Prompt)

Using the same `rag_Assistant` environment from before:

```
conda activate rag_Assistant
cd path\to\rag_assistant_streamlit_deploy
pip install -r requirements.txt
streamlit run app.py
```

**Important:** Streamlit apps are launched with `streamlit run app.py`, never
`python app.py` — that's the single most common mistake. Using `python` will either
error out or silently do nothing useful.

What happens next:
- A local server starts and should auto-open your browser at `http://localhost:8501`.
  If it doesn't, copy the "Local URL" printed in the terminal into your browser.
- The first run may ask for an email for their newsletter — optional, press Enter to skip.
- Stop the server anytime with `Ctrl+C` in the terminal.

If port 8501 is already taken:
```
streamlit run app.py --server.port 8502
```

---

## 2. Deploy to Streamlit Community Cloud (free)

1. Put these files in a GitHub repo (Streamlit Cloud deploys from GitHub, not by
   direct file upload). Create a new repo and push `app.py`, `requirements.txt`,
   `sample_document.txt`, and `eval_qa.json` to it.
2. Go to <https://share.streamlit.io> and sign in with GitHub.
3. Click **New app**, select your repo, branch, and set **Main file path** to `app.py`.
4. Click **Deploy**. Streamlit Cloud installs `requirements.txt` automatically —
   watch the build log if anything fails.
5. **Add your OpenAI API key (optional, for real LLM answers):**
   - In your deployed app, open **Settings** (⋮ menu) → **Secrets**.
   - Add:
     ```toml
     OPENAI_API_KEY = "sk-..."
     ```
   - This becomes available to the app the same way `st.secrets["OPENAI_API_KEY"]`
     or `os.environ.get("OPENAI_API_KEY")` would read it. `app.py` currently reads
     from the sidebar box or the environment variable — you can wire in
     `st.secrets` too if you want the key to work without typing it in each time.
   - Without a key, the app still works fully via the template fallback answer.
6. Your app will be live at `https://<your-app-name>.streamlit.app`.

**Updating later:** push a new commit to the connected GitHub repo — Streamlit Cloud
redeploys automatically.

---

## 3. Fixing "ModuleNotFoundError" even after `pip install` (pypdf, python-docx, etc.)

This is almost always an environment mismatch — one terminal/environment installed
the package, a different one is running the app.

1. **Confirm your conda environment is active** — your prompt should show
   `(rag_Assistant)` at the start. If it doesn't:
   ```
   conda activate rag_Assistant
   ```
2. **Confirm which Python Streamlit is actually using:**
   ```
   python -c "import sys; print(sys.executable)"
   ```
   It should point inside your `rag_Assistant` environment folder.
3. **Install using that exact interpreter:**
   ```
   python -m pip install pypdf python-docx
   ```
4. **Restart the Streamlit server** after installing — `Ctrl+C`, then
   `streamlit run app.py` again. Streamlit does not pick up newly installed
   packages in an already-running session.
5. **Check the package name** — the import is `import pypdf` (no "2"). An older,
   unmaintained package called `PyPDF2` won't satisfy this import even if installed.
6. **Verify:**
   ```
   python -c "import pypdf; print(pypdf.__version__)"
   ```
   If this prints a version in the same terminal you launch Streamlit from, the app
   will find it too.

`app.py` in this package also surfaces this exact guidance inside the UI if a
PDF/DOCX upload fails due to a missing import.

---

## 4. How this app differs from a plain script (Streamlit-specific behavior)

- **Streamlit re-runs the whole script top to bottom on every click or widget
  change.** Anything that must survive between reruns — like your processed
  document index — is stored in `st.session_state`, not a plain variable. If you
  edit the app and something you expect to "remember" resets unexpectedly, check
  it's in `st.session_state`.
- **Editing while it's running:** save your edit, then click the "Rerun" prompt
  that appears in the browser (or press `R`) — no need to restart the server.
- **Upload limit:** Streamlit's default is 200MB per file, far more than needed here.

---

## 5. Testing accuracy with the sample document

1. Run the app (locally or on Streamlit Cloud).
2. Upload `sample_document.txt`, click **Process Documents**.
3. Ask questions from `eval_qa.json`, e.g. *"What is the refund window for annual
   plans?"*, and compare the answer + retrieved chunk against that file's
   `expected_answer_contains` / `source_fact` fields.
4. Or run it headlessly:
   ```
   python run_eval.py
   ```
   Chunks the document, retrieves context for all 10 eval questions, generates
   answers, and reports how many matched — a quick regression check any time you
   change chunking or retrieval settings. (You'll see some harmless "missing
   ScriptRunContext" warnings — expected, see the note at the top of `run_eval.py`.)

## 6. Troubleshooting

| Symptom | Likely cause |
|---|---|
| `ModuleNotFoundError` on startup | Wrong environment active, or install didn't complete — see section 3. |
| Nothing happens running `python app.py` | Must use `streamlit run app.py`, not `python`. |
| "Port already in use" | Use `--server.port 8502` or stop the other Streamlit process. |
| PDF upload gives empty/garbled text | Some PDFs are scanned images, not real text — `pypdf` only extracts already-selectable text. |
| Answer looks like raw document text glued together | No API key set — this is the expected template fallback, not a bug. |
