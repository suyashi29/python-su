"""
RAG Assistant — Streamlit App (single file)
=============================================
See the "STREAMLIT SETUP — READ THIS FIRST" instructions below, or in the
accompanying README, before running.
"""

import os
import re
import sys

import numpy as np
import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ---------------------------------------------------------------------------
# Document loading
# ---------------------------------------------------------------------------

def extract_text_from_upload(uploaded_file):
    """Return plain text from a Streamlit UploadedFile (.txt, .pdf, or .docx)."""
    name = uploaded_file.name.lower()

    if name.endswith(".txt"):
        return uploaded_file.read().decode("utf-8", errors="ignore")

    if name.endswith(".pdf"):
        try:
            from pypdf import PdfReader
        except ImportError as e:
            raise ImportError(
                "Could not import 'pypdf'. If you've already run `pip install pypdf` "
                "and still see this, it almost always means pip installed it into a "
                "different Python environment than the one running Streamlit. Fix: run "
                f"`{sys.executable} -m pip install pypdf` (this guarantees the same "
                "interpreter Streamlit is using), then restart the app "
                "(Ctrl+C, then `streamlit run app.py` again)."
            ) from e
        reader = PdfReader(uploaded_file)
        return "\n".join((page.extract_text() or "") for page in reader.pages)

    if name.endswith(".docx"):
        try:
            import docx
        except ImportError as e:
            raise ImportError(
                "Could not import 'python-docx'. Run "
                f"`{sys.executable} -m pip install python-docx` (note: the PyPI "
                "package is named 'python-docx' even though you `import docx`), then "
                "restart the app."
            ) from e
        doc = docx.Document(uploaded_file)
        return "\n".join(p.text for p in doc.paragraphs)

    raise ValueError(f"Unsupported file type: {uploaded_file.name}. Use .txt, .pdf, or .docx")


def chunk_text(text, chunk_size=100, overlap=20):
    """Sentence-aware chunking: packs whole sentences into chunks of up to
    `chunk_size` words instead of cutting mid-sentence, carrying the last
    `overlap` words into the next chunk so a fact split across a boundary
    isn't lost entirely on either side."""
    normalized = re.sub(r"\s+", " ", text).strip()
    sentences = [s for s in re.split(r"(?<=[.!?])\s+", normalized) if s]

    chunks = []
    current_words = []
    for sentence in sentences:
        sentence_words = sentence.split()
        if current_words and len(current_words) + len(sentence_words) > chunk_size:
            chunks.append(" ".join(current_words))
            current_words = current_words[-overlap:] if overlap else []
        current_words.extend(sentence_words)
    if current_words:
        chunks.append(" ".join(current_words))
    return chunks


# ---------------------------------------------------------------------------
# Retrieval
# ---------------------------------------------------------------------------

def build_index(chunks):
    vectorizer = TfidfVectorizer(stop_words="english")
    matrix = vectorizer.fit_transform(chunks)
    return vectorizer, matrix


def retrieve(query, vectorizer, matrix, chunks, k=4):
    q_vec = vectorizer.transform([query])
    scores = cosine_similarity(q_vec, matrix)[0]
    ranked_idx = np.argsort(scores)[::-1][:k]
    return [(chunks[i], float(scores[i])) for i in ranked_idx]


# ---------------------------------------------------------------------------
# Generation
# ---------------------------------------------------------------------------

def _template_fallback_answer(context_chunks):
    return "Based on the uploaded documents: " + " ".join(context_chunks)


def generate_answer(query, context_chunks, api_key):
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        return _template_fallback_answer(context_chunks)

    try:
        from openai import OpenAI
        client = OpenAI(api_key=key)
        context_text = "\n".join(f"- {c}" for c in context_chunks)
        prompt = (
            "Answer the question using ONLY the context below. "
            "If the context doesn't contain the answer, say so.\n\n"
            f"Context:\n{context_text}\n\nQuestion: {query}\nAnswer:"
        )
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return f"[LLM call failed: {e}]\n\n" + _template_fallback_answer(context_chunks)


# ---------------------------------------------------------------------------
# Lightweight evaluation metrics (no ground truth required)
# ---------------------------------------------------------------------------

def tfidf_cosine(text_a, text_b):
    local_vec = TfidfVectorizer(stop_words="english").fit([text_a, text_b])
    vecs = local_vec.transform([text_a, text_b])
    return float(cosine_similarity(vecs[0], vecs[1])[0][0])


def faithfulness_proxy(answer, context_chunks):
    return tfidf_cosine(answer, " ".join(context_chunks))


def answer_relevancy_proxy(answer, query):
    return tfidf_cosine(answer, query)


# ---------------------------------------------------------------------------
# Streamlit UI
# ---------------------------------------------------------------------------
# NOTE: Streamlit re-runs this entire script top-to-bottom on every interaction
# (every button click, every widget change). Anything you need to persist across
# reruns — the built index, chat history, etc. — must live in `st.session_state`,
# not in a plain local variable. That's why the index lives in
# `st.session_state.index_state` below instead of a normal variable.

st.set_page_config(page_title="RAG Assistant", page_icon="📄", layout="wide")

if "index_state" not in st.session_state:
    st.session_state.index_state = None
if "status" not in st.session_state:
    st.session_state.status = ""

st.title("📄 RAG Assistant")
st.caption("Upload documents, process them, then ask questions grounded in their content.")

with st.sidebar:
    st.header("Settings")
    api_key = st.text_input(
        "OpenAI API Key (optional)",
        type="password",
        placeholder="sk-...",
        help="Leave blank to use OPENAI_API_KEY from your environment, or to fall back to a template answer.",
    )
    k = st.slider("Chunks to retrieve (K)", min_value=1, max_value=10, value=4)
    st.markdown("---")
    st.markdown(
        "**Supported files:** `.txt`, `.pdf`, `.docx`\n\n"
        "**Metrics shown:** Faithfulness proxy and Answer Relevancy proxy "
        "(TF-IDF cosine-similarity stand-ins — see the guided lab for full detail)."
    )

uploaded_files = st.file_uploader(
    "Upload documents",
    type=["txt", "pdf", "docx"],
    accept_multiple_files=True,
)

if st.button("Process Documents", type="primary"):
    if not uploaded_files:
        st.warning("Upload at least one .txt, .pdf, or .docx file first.")
    else:
        all_chunks = []
        file_names = []
        error = None
        for f in uploaded_files:
            try:
                text = extract_text_from_upload(f)
            except Exception as e:
                error = f"Failed to read {f.name}: {e}"
                break
            all_chunks.extend(chunk_text(text))
            file_names.append(f.name)

        if error:
            st.error(error)
        elif not all_chunks:
            st.error("No extractable text found in the uploaded file(s).")
        else:
            vectorizer, matrix = build_index(all_chunks)
            st.session_state.index_state = {
                "vectorizer": vectorizer,
                "matrix": matrix,
                "chunks": all_chunks,
            }
            st.session_state.status = (
                f"Indexed {len(all_chunks)} chunks from {len(file_names)} file(s): "
                f"{', '.join(file_names)}"
            )

if st.session_state.status:
    st.success(st.session_state.status)

st.markdown("---")

question = st.text_input("Your question", placeholder="Ask something about the uploaded documents...")
ask_clicked = st.button("Get Answer", type="primary")

if ask_clicked:
    if not st.session_state.index_state:
        st.warning("Please upload and process documents first.")
    elif not question or not question.strip():
        st.warning("Please enter a question.")
    else:
        index_state = st.session_state.index_state
        with st.spinner("Retrieving context and generating answer..."):
            results = retrieve(
                question, index_state["vectorizer"], index_state["matrix"], index_state["chunks"], k=k
            )
            context_chunks = [c for c, _ in results]
            answer = generate_answer(question, context_chunks, api_key)
            faith = faithfulness_proxy(answer, context_chunks)
            rel = answer_relevancy_proxy(answer, question)

        st.subheader("Answer")
        st.write(answer)

        col1, col2 = st.columns(2)
        col1.metric("Faithfulness proxy", f"{faith:.2f}")
        col2.metric("Answer Relevancy proxy", f"{rel:.2f}")

        with st.expander("Retrieved chunks", expanded=False):
            chunks_df = pd.DataFrame(
                [{"rank": i + 1, "score": round(s, 3), "chunk": c} for i, (c, s) in enumerate(results)]
            )
            st.dataframe(chunks_df, use_container_width=True)
