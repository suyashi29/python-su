---
title: RAG Assistant
emoji: 📄
colorFrom: blue
colorTo: teal
sdk: gradio
sdk_version: 5.0.0
app_file: app.py
pinned: false
---

# RAG Assistant — Gradio Deployment Package

A document-upload RAG assistant, packaged for one-click deployment to
[Hugging Face Spaces](https://huggingface.co/spaces) (or any host that runs a Gradio
`app.py`).

**Files in this package:**
- `app.py` — the Gradio app (this is the file Spaces looks for by default)
- `requirements.txt` — dependencies, installed automatically by Spaces
- `sample_document.txt` — a 100-line test document (fictional SaaS company knowledge base)
- `eval_qa.json` — 10 question/answer pairs matched to facts in `sample_document.txt`
- `run_eval.py` — scores the app's retrieval + answers against `eval_qa.json`

---

## Option A — Deploy to Hugging Face Spaces (recommended, free)

1. Go to <https://huggingface.co/new-space> and create an account if you don't have one.
2. Fill in:
   - **Space name**: anything, e.g. `rag-assistant`
   - **SDK**: choose **Gradio**
   - **Hardware**: the free CPU tier is enough for this app
3. Once the Space is created, upload all files in this folder (`app.py`,
   `requirements.txt`, `sample_document.txt`, `eval_qa.json`) via the Space's
   **Files** tab → **Add file** → **Upload files**. Drag-and-drop all of them.
4. The Space will automatically detect `requirements.txt`, install dependencies, and
   launch `app.py`. Build logs are visible under the **Logs** tab — watch here if
   something fails to install.
5. **Add your OpenAI API key (optional, for real LLM answers):**
   - Go to your Space's **Settings** tab → **Variables and secrets**.
   - Add a new **secret** named `OPENAI_API_KEY` with your key as the value.
   - Secrets are injected as environment variables automatically — no code change
     needed, since `app.py` already reads `os.environ.get("OPENAI_API_KEY")`.
   - Without this secret, the app still works fully using the template fallback
     answer.
6. Your Space will be live at `https://huggingface.co/spaces/<your-username>/<space-name>`.

**Updating later:** just upload a new version of `app.py` (or any file) through the
Files tab, or connect the Space to a GitHub repo for git-based deploys if you prefer.

---

## Option B — Run locally first (recommended before deploying)

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open the local URL Gradio prints (usually `http://127.0.0.1:7860`).

---

## Fixing "ModuleNotFoundError" even after `pip install`

This is almost always an environment mismatch, not a broken install. Two things
installed pypdf/python-docx into environment A, but the app is running in
environment B (a different Python). Steps to confirm and fix:

1. **Check which Python is actually running the app:**
   ```bash
   python3 -c "import sys; print(sys.executable)"
   ```
2. **Install using that exact interpreter**, not just `pip install`:
   ```bash
   python3 -m pip install pypdf python-docx
   ```
   Using `python3 -m pip` (instead of a bare `pip`) guarantees the package lands in
   the same environment that `python3` (or `python3 app.py`) will actually use.
3. **If you're using a virtual environment**, make sure it's activated in the same
   terminal you're running the app from — look for `(venv)` at the start of your
   prompt. Installing outside the venv and running inside it (or vice versa) is the
   single most common cause of this error.
4. **If you're in Jupyter**, installing a package does not update an already-running
   kernel. Restart the kernel after installing.
5. **Double-check the package name.** The import is `import pypdf`, but note there's
   also an older, unmaintained package called `PyPDF2` — installing the wrong one
   won't satisfy `import pypdf`. This app uses `pypdf` (no "2").
6. **Verify the fix:**
   ```bash
   python3 -c "import pypdf; print(pypdf.__version__)"
   ```
   If this prints a version number in the same terminal you'll launch the app
   from, the app will find it too.

The updated `app.py` in this package also surfaces this exact guidance inside the UI
if a PDF/DOCX upload fails due to a missing import, so you shouldn't need to guess.

---

## Testing accuracy with the sample document

1. Run the app (locally or on your deployed Space).
2. Upload `sample_document.txt`, click **Process Documents**.
3. Ask a few questions from `eval_qa.json`, e.g. *"What is the refund window for
   annual plans?"* and compare the answer + retrieved chunk against the
   `expected_answer_contains` / `source_fact` fields in that file.
4. Or run it automatically without the UI:
   ```bash
   python run_eval.py
   ```
   This chunks `sample_document.txt`, retrieves context for all 10 eval questions,
   generates answers, and reports how many matched — a quick regression check any
   time you change chunking or retrieval settings.
