"""
RAG Assistant — Gradio App (single file)
=========================================

A document-upload RAG assistant with the same retrieval + evaluation-metric logic
from the guided lab, wrapped in a Gradio UI.

SETUP
-----
1. Install dependencies:
     pip install gradio scikit-learn pandas numpy pypdf python-docx openai

2. (Optional) Set your OpenAI API key as an environment variable so the app
   generates real LLM answers instead of falling back to an extractive template:
     export OPENAI_API_KEY="sk-..."        # macOS/Linux
     set OPENAI_API_KEY=sk-...             # Windows (cmd)
     $env:OPENAI_API_KEY="sk-..."          # Windows (PowerShell)

   You can also paste a key directly into the "OpenAI API Key" box in the UI —
   that box always takes priority over the environment variable.

3. Run:
     python rag_gradio_app.py

4. Gradio will print a local URL (usually http://127.0.0.1:7860). Open it in your
   browser, upload a .txt, .pdf, or .docx file, click "Process Documents", then ask
   a question.

Supported file types: .txt, .pdf, .docx
Libraries used are deliberately lightweight and pure-Python where possible
(pypdf, python-docx) to avoid native-binary install issues.
"""

import os
import re
import sys

import gradio as gr
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ---------------------------------------------------------------------------
# Document loading
# ---------------------------------------------------------------------------

def extract_text_from_file(file_path):
    """Return plain text from a .txt, .pdf, or .docx file."""
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".txt":
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    if ext == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError as e:
            raise ImportError(
                "Could not import 'pypdf'. If you've already run `pip install pypdf` "
                "and still see this, it almost always means pip installed it into a "
                "different Python environment than the one running this app. Fix: run "
                f"`{sys.executable} -m pip install pypdf` (this guarantees the same "
                "interpreter), then restart the app. If you're in Jupyter, restart the "
                "kernel after installing — a running kernel won't see new packages."
            ) from e
        reader = PdfReader(file_path)
        return "\n".join((page.extract_text() or "") for page in reader.pages)

    if ext == ".docx":
        try:
            import docx
        except ImportError as e:
            raise ImportError(
                "Could not import 'python-docx'. Run "
                f"`{sys.executable} -m pip install python-docx` (note: the PyPI "
                "package is named 'python-docx' even though you `import docx`), then "
                "restart the app."
            ) from e
        doc = docx.Document(file_path)
        return "\n".join(p.text for p in doc.paragraphs)

    raise ValueError(f"Unsupported file type: {ext}. Use .txt, .pdf, or .docx")


def chunk_text(text, chunk_size=100, overlap=20):
    """Sentence-aware chunking: packs whole sentences into chunks of up to
    `chunk_size` words instead of cutting mid-sentence, carrying the last
    `overlap` words into the next chunk so a fact split across a boundary
    isn't lost entirely on either side."""
    normalized = re.sub(r"\s+", " ", text).strip()
    sentences = [s for s in re.split(r"(?<=[.!?])\s+", normalized) if s]

    chunks = []
    current_words = []
    for sentence in sentences:
        sentence_words = sentence.split()
        if current_words and len(current_words) + len(sentence_words) > chunk_size:
            chunks.append(" ".join(current_words))
            current_words = current_words[-overlap:] if overlap else []
        current_words.extend(sentence_words)
    if current_words:
        chunks.append(" ".join(current_words))
    return chunks


# ---------------------------------------------------------------------------
# Retrieval
# ---------------------------------------------------------------------------

def build_index(chunks):
    vectorizer = TfidfVectorizer(stop_words="english")
    matrix = vectorizer.fit_transform(chunks)
    return vectorizer, matrix


def retrieve(query, vectorizer, matrix, chunks, k=4):
    q_vec = vectorizer.transform([query])
    scores = cosine_similarity(q_vec, matrix)[0]
    ranked_idx = np.argsort(scores)[::-1][:k]
    return [(chunks[i], float(scores[i])) for i in ranked_idx]


# ---------------------------------------------------------------------------
# Generation
# ---------------------------------------------------------------------------

def _template_fallback_answer(context_chunks):
    return "Based on the uploaded documents: " + " ".join(context_chunks)


def generate_answer(query, context_chunks, api_key):
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        return _template_fallback_answer(context_chunks)

    try:
        from openai import OpenAI
        client = OpenAI(api_key=key)
        context_text = "\n".join(f"- {c}" for c in context_chunks)
        prompt = (
            "Answer the question using ONLY the context below. "
            "If the context doesn't contain the answer, say so.\n\n"
            f"Context:\n{context_text}\n\nQuestion: {query}\nAnswer:"
        )
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return f"[LLM call failed: {e}]\n\n" + _template_fallback_answer(context_chunks)


# ---------------------------------------------------------------------------
# Lightweight evaluation metrics (no ground truth required)
# ---------------------------------------------------------------------------

def tfidf_cosine(text_a, text_b):
    local_vec = TfidfVectorizer(stop_words="english").fit([text_a, text_b])
    vecs = local_vec.transform([text_a, text_b])
    return float(cosine_similarity(vecs[0], vecs[1])[0][0])


def faithfulness_proxy(answer, context_chunks):
    return tfidf_cosine(answer, " ".join(context_chunks))


def answer_relevancy_proxy(answer, query):
    return tfidf_cosine(answer, query)


# ---------------------------------------------------------------------------
# Gradio callbacks
# ---------------------------------------------------------------------------

def process_documents(files):
    if not files:
        return None, "Upload at least one .txt, .pdf, or .docx file first."

    all_chunks = []
    file_names = []
    for f in files:
        try:
            text = extract_text_from_file(f.name)
        except Exception as e:
            return None, f"Failed to read {os.path.basename(f.name)}: {e}"
        chunks = chunk_text(text)
        all_chunks.extend(chunks)
        file_names.append(os.path.basename(f.name))

    if not all_chunks:
        return None, "No extractable text found in the uploaded file(s)."

    vectorizer, matrix = build_index(all_chunks)
    index_state = {"vectorizer": vectorizer, "matrix": matrix, "chunks": all_chunks}
    status = f"Indexed {len(all_chunks)} chunks from {len(file_names)} file(s): {', '.join(file_names)}"
    return index_state, status


def ask_question(question, index_state, api_key, k):
    if not index_state:
        return "Please upload and process documents first.", pd.DataFrame(), ""
    if not question or not question.strip():
        return "Please enter a question.", pd.DataFrame(), ""

    results = retrieve(
        question, index_state["vectorizer"], index_state["matrix"], index_state["chunks"], k=int(k)
    )
    context_chunks = [c for c, _ in results]
    answer = generate_answer(question, context_chunks, api_key)

    chunks_df = pd.DataFrame(
        [{"rank": i + 1, "score": round(s, 3), "chunk": c} for i, (c, s) in enumerate(results)]
    )

    faith = faithfulness_proxy(answer, context_chunks)
    rel = answer_relevancy_proxy(answer, question)
    metrics_md = (
        f"**Faithfulness proxy:** {faith:.2f}  \n"
        f"**Answer Relevancy proxy:** {rel:.2f}  \n\n"
        f"_These are TF-IDF cosine-similarity proxies — see the guided lab notebook "
        f"for how they relate to full RAGAS/TruLens-style metrics._"
    )
    return answer, chunks_df, metrics_md


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

with gr.Blocks(title="RAG Assistant") as demo:
    gr.Markdown(
        "# 📄 RAG Assistant\n"
        "Upload documents, click **Process Documents**, then ask a question. "
        "Retrieved chunks and lightweight evaluation metrics are shown alongside the answer."
    )

    index_state = gr.State(None)

    with gr.Row():
        with gr.Column(scale=1):
            files_in = gr.File(
                label="Upload documents (.txt, .pdf, .docx)",
                file_count="multiple",
                file_types=[".txt", ".pdf", ".docx"],
            )
            process_btn = gr.Button("Process Documents", variant="primary")
            status_out = gr.Markdown()
            api_key_in = gr.Textbox(
                label="OpenAI API Key (optional — leave blank to use a template fallback answer)",
                type="password",
                placeholder="sk-...",
            )
            k_slider = gr.Slider(1, 10, value=4, step=1, label="Chunks to retrieve (K)")

        with gr.Column(scale=2):
            question_in = gr.Textbox(label="Your question", placeholder="Ask something about the uploaded documents...")
            ask_btn = gr.Button("Get Answer", variant="primary")
            answer_out = gr.Markdown(label="Answer")
            metrics_out = gr.Markdown(label="Metrics")
            chunks_out = gr.Dataframe(label="Retrieved chunks", wrap=True)

    process_btn.click(process_documents, inputs=[files_in], outputs=[index_state, status_out])
    ask_btn.click(
        ask_question,
        inputs=[question_in, index_state, api_key_in, k_slider],
        outputs=[answer_out, chunks_out, metrics_out],
    )

if __name__ == "__main__":
    demo.launch()
